
Blast_par_replace_perl2 <- function(Dir, Gene, WordSize_){

  blast_file <- paste(Dir, paste(Gene, "_Haplotype.fa",sep=''), sep='')

  sys_command_0_ <- paste("samtools faidx ",blast_file ,sep=' ')

  system(sys_command_0_)

  all_genomes <- system( paste("grep '>' ", blast_file,  " | sed s'/>//g'", sep=''), intern=TRUE )

  All_VS_ALL_Alignment_ <- function(index_){

	 out_file2 <- paste(Dir, paste(Gene,"_", all_genomes[index_], "_line.fa",sep=''), sep='')

	 sys_command_2 <- paste("samtools faidx ",blast_file, all_genomes[index_]," > ", out_file2 ,sep=' ')

	 system(sys_command_2)

	 out_file_ <- paste(Dir, paste(Gene,"_", all_genomes[index_], "_Blastn_.txt",sep=''), sep='')

	 sys_command_1_ <- paste("/usr/local/bin/blastn -db ", blast_file, " -query ", out_file2, " -word_size ", WordSize_ ," -out ",out_file_," -outfmt 6 -evalue 10 ",sep='')

	 system(sys_command_1_)

	 system( paste("rm", out_file2 ,sep=' ') )

  }

  no_cores <- 6

  registerDoParallel(cores=no_cores)  

  cl <- makeCluster(no_cores, type="FORK")  

  #system.time(
	#result <- parLapply(cl, 1:length(all_genomes), All_VS_ALL_Alignment_)
  #)
  

  #result <- parLapply(cl, 1:length(all_genomes), All_VS_ALL_Alignment_)

  result <- foreach(i=1:length(all_genomes)) %dopar% All_VS_ALL_Alignment_(i)

  stopCluster(cl)

  system(paste('cat ',Dir, '*_Blastn_.txt > ', Dir, Gene, '_Haplotype-Self_out_m8',sep='' ))

  system( paste("rm ", Dir ,'*_Blastn_.txt', sep='') )

#####################################################################
  repeat_file <- paste(database_folder, 'Repeat/grasrep.fa', sep='')

  All_VS_Repeat_Alignment_ <- function(index_){

	 out_file2 <- paste(Dir, paste(Gene,"_", all_genomes[index_], "_line.fa",sep=''), sep='')

	 sys_command_2 <- paste("samtools faidx ",blast_file, all_genomes[index_]," > ", out_file2 ,sep=' ')

	 system(sys_command_2)

	 out_file_ <- paste(Dir, paste(Gene,"_", all_genomes[index_], "_Blastn_Repeat.txt",sep=''), sep='')

	 sys_command_1_ <- paste("/usr/local/bin/blastn -db ", repeat_file, " -query ", out_file2, " -out ",out_file_," -outfmt 6 -evalue 10 ",sep='')

	 system(sys_command_1_)

	 system( paste("rm", out_file2 ,sep=' ') )

  }

  no_cores <- 6

  registerDoParallel(cores=no_cores)  

  cl <- makeCluster(no_cores, type="FORK")  

  #system.time(
	# result_rep <- parLapply(cl, 1:length(all_genomes), All_VS_Repeat_Alignment_)
  #)

  #result_rep <- parLapply(cl, 1:length(all_genomes), All_VS_Repeat_Alignment_)

  result_rep <- foreach(i=1:length(all_genomes)) %dopar% All_VS_Repeat_Alignment_(i)
  
  stopCluster(cl)

  system(paste('cat ',Dir, '*_Blastn_Repeat.txt > ', Dir, Gene, '_repMask2',sep='' ))

  system( paste("rm ", Dir ,'*_Blastn_Repeat.txt', sep='') )

}
##############################################
#Dir <-'/mnt/compbiolab/bszhang/User/Test_Blast_perl/'
#Gene <- "Zm00001eb143080.1"
#gDNAs_blast_ <- read.table(paste(Dir, Gene, '_Haplotype-Self_out_m8', sep = ''), sep = '\t', header = F, stringsAsFactors = F)


CLIPS_par <- function( gDNAs_blast_ ){


  Slope_by_HSPs <- function(gDNAs_, g1_, g2_, g1_self_, g2_self_) {
  
    gDNAs <- subset(gDNAs_, gDNAs_[,1] == g1_ & gDNAs_[,2] == g2_)
  
    exact_match <- unique(c(which(gDNAs[,7] %in% g1_self_[,7] & gDNAs[,8] %in% g1_self_[,8]), which(gDNAs[,9] %in% g2_self_[,7] & gDNAs[,10] %in% g2_self_[,8])))
  
    if (length(exact_match) > 0) { gDNAs <- gDNAs[-exact_match,]}
  
    if (nrow(g1_self_) > 0 & nrow(g2_self_) > 0 & nrow(gDNAs) > 1) { gDNAs <- Remove_CrossOverMatch(gDNAs, g1_self_, g2_self_) }
  
    q_hits <- c(gDNAs[,7], gDNAs[,8]); s_hits <- c(gDNAs[,9,], gDNAs[,10])
  
    b_ <- round(lm(q_hits ~ s_hits)$coeff[2], 2)
  
    return (b_)
  }

  Remove_CrossOverMatch <- function(gDNAs_, g1_self_, g2_self_) {
  
    rep_tag <- c()
  
    for (i in 1:nrow(gDNAs_)) {
    
      for (j in 1:nrow(g1_self_)) {
    
        g1_s_e <- sort(c(g1_self_[j,7], g1_self_[j,8], gDNAs_[i,7], gDNAs_[i,8]))
      
        d_s <- abs(g1_s_e[1] - g1_s_e[2]) + abs(g1_s_e[3] - g1_s_e[4]);
      
        if (d_s < 20) { rep_tag <- append(rep_tag, i); break} ## 20 can be changed
      }
      ## check the subject columns might be reduant, but just be safe
      for (k in 1:nrow(g2_self_)) {
   
        g2_s_e <- sort(c(g2_self_[k,7], g2_self_[k,8], gDNAs_[i,9], gDNAs_[i,10]))
   
        d_s <- abs(g2_s_e[1] - g2_s_e[2]) + abs(g2_s_e[3] - g2_s_e[4]);
      
        if (d_s < 20) { rep_tag <- append(rep_tag, i); break} ## 20 can be changed
      }
    }
 
    if (length(rep_tag) > 0) { gDNAs_ <- gDNAs_[-unique(rep_tag),] }
  
    return(gDNAs_);
  }

  ##
  #gDNAs_blast_ <- read.table(paste(Dir, Gene, '_Haplotype-Self_out_m8', sep = ''), sep = '\t', header = F, stringsAsFactors = F)

  genomes <- as.vector(unique(gDNAs_blast_[,1]));

  self_idx <- which(gDNAs_blast_[,1] == gDNAs_blast_[,2])

  g_selfs <- gDNAs_blast_[self_idx,]
  
  g_selfs <- g_selfs[(g_selfs[,7] - g_selfs[,9] + g_selfs[,8] - g_selfs[,10] != 0),]

  gDNAs_blast_0 <- gDNAs_blast_[-self_idx,]

  n_g <- length(genomes)  

  b_matrix <- diag(n_g)

  CLIPS_ <- function( g1_index ){

    #for (g1_index in 1:(n_g - 1)) {
    #b_matrix <- diag(n_g)

    g1_self <- subset(g_selfs, g_selfs[,1] == genomes[g1_index])

    for (g2 in (g1_index + 1): n_g ) {
  
      g2_self <- subset(g_selfs, g_selfs[,1] == genomes[g2]) 
  
      b_matrix[g1_index, g2] <- Slope_by_HSPs(gDNAs_blast_0, genomes[g1_index], genomes[g2], g1_self, g2_self)
      
      b_matrix[g2, g1_index] <- Slope_by_HSPs(gDNAs_blast_0, genomes[g2], genomes[g1_index], g2_self, g1_self)

    }
    #}

    colnames(b_matrix) <- genomes
  
    rownames(b_matrix) <- genomes
  
    return (b_matrix)

  }

  #system.time( test <- CLIPS_ () )

  no_cores <- 6

  registerDoParallel(cores=no_cores)  

  cl <- makeCluster(no_cores, type="FORK")  

  #system.time(
  #{ result_CLIPS_ <- foreach(i=1:(n_g-1) ) %dopar% CLIPS_(i) }
  #)

  #system.time(
	# { result_CLIPS <- parLapply(cl, 1:(n_g - 1), CLIPS_) }
  #)

  #result_CLIPS <- parLapply(cl, 1:(n_g - 1), CLIPS_)

  result_CLIPS <- foreach(i=1:(n_g - 1)) %dopar% CLIPS_(i)


  stopCluster(cl)


  b_matrix_combined <- diag(n_g)

  for (g1_index in (n_g - 1):1) {

    for (g2 in (g1_index + 1): n_g ) {
  
      b_matrix_combined[g1_index, g2] <- result_CLIPS[[g1_index]][g1_index, g2]
      
      b_matrix_combined[g2, g1_index] <- result_CLIPS[[g1_index]][g2, g1_index]

    }

  }

  colnames(b_matrix_combined) <- genomes
  
  rownames(b_matrix_combined) <- genomes
  
  return(b_matrix_combined)

}