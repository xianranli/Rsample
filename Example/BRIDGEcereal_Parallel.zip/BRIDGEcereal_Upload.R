
options(shiny.maxRequestSize=300*1024^2) ## Max size of uploaded file (300Mb in this case)

BRIDGEcereal_Upload <- function( gff_folder ){

    page(

    href = "/Upload",

        ui <-  function(request){

            tagList(

                #fluidPage(theme = shinytheme("readable")),

                # h2("BRIDGEcereal webapp is under maintance and will come back ASAP.",style="text-align:center"),

                # nav_links,

                useShinyjs(),

                #sidebarLayout(

                sidebarPanel(

                
                    column(12,
                        pickerInput(
                            inputId = "Up_load", 
                            label = "Upload gff/cds files :", 
                            choices = c('Wheat','Maize', 'Sorghum', 'Rice', 'Barley', 'Soybean'),
                            selected = c(''), ## by default
                            options = list(
                            'actions-box' = TRUE, 
                            size = 15, 
                            'selected-text-format' = "count > 1"
                            ), 
                            multiple = FALSE,
                            )
                    ),


                    column(12, fileInput("upload_anno", "Upload gff and cds (.gz file)") ),


                ), # sidebarPanel


                mainPanel(

                    fluidRow(

                        #column(12, offset=3,align="center", h3("")),

                        #### progress in middle
                        tags$head(
                            tags$style(
                            HTML(".shiny-notification {
                            height: 100px;
                            width: 800px;
                            position:fixed;
                            top: calc(50% - 50px);;
                            left: calc(50% - 400px);;
                            }
                            "
                            )
                            )
                         ),
                        #### progress in middle

                        textOutput('upload_anno_text'),

                        tags$head(tags$style("#upload_anno_text{color: black;
                                 font-size: 38px;
                                 font-style: italic;
                                 }"
                                )
                        ),


                    ) # fluidRow

                ) # mainPanel

                #) # sidebarLayout

            ) # For tagList

        }, # For ui function

        server <- function(input, output, session){

            observeEvent( input$upload_anno, {

            progress <- Progress$new(session, min=1, max=10)
    
            on.exit(progress$close())
    
            progress$set(message = 'Processing your compressed file Parent1 ...',
                detail = 'Almost there...')
        
            for (i in 1:5) {
        
                progress$set(value = i)
                
                Sys.sleep(0.3)
            }

            if (is.null(input$upload_anno)) return()
            #############

            #Test_gff_folder <- paste('/mnt/compbiolab/bszhang/script_V2_Par/Test_upload/', input$Up_load, sep='')
            
            Test_gff_folder <- paste(gff_folder, input$Up_load, sep='')

            #tar -zcvf Wheat.tar.gz Wheat
            #tar -xzvf file.tar.gz

            #############
       
            file.copy(input$upload_anno$datapath, paste0(Test_gff_folder,'/',input$upload_anno$name) )

          
            upload_name <- input$upload_anno$name
    
            #print(upload_name)

            
            fileName0<- paste(Test_gff_folder,'/',upload_name,sep='')

            fileName1 <- as.character(strsplit(fileName0, ".gz"))

            #print(fileName1) 
          
            uncompressed0 <- paste("gzip -d",fileName0, sep=' ') 
          
            uncompressed1 <- system(uncompressed0)

            if( length( grep('.fa', upload_name) ) == 1 ){

                samtools0 <- paste('samtools faidx',fileName1 ,sep=' ')
          
                samtools1 <- system(samtools0)

            }

            Test_upload_gff <- paste("It's done!",sep='')
    
            output$upload_anno_text <- renderText({ Test_upload_gff })


            }) ## observe
            ######

        } #

    ) # 

}