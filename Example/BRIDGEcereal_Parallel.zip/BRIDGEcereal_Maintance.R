
BRIDGEcereal_Maintance <- function(){

    page(

        href = "/",

        ui <-  function(request){

            tagList(

                #fluidPage(theme = shinytheme("readable")),

                h2("BRIDGEcereal webapp is under maintance and will come back ASAP.",style="text-align:center"),

                # nav_links,

                useShinyjs(),

                #sidebarLayout(

                #sidebarPanel(

                #), # sidebarPanel

                mainPanel(

                    fluidRow(

                        #column(12, offset=3,align="center", h3("")),

                    ) # fluidRow

                ) # mainPanel

                #) # sidebarLayout

            ) # For tagList
        }, # For ui function

        server <- function(input, output, session){
        } #
    ) # 
}